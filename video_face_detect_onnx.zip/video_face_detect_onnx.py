"""
This code uses to detect faces from live video using onnx model.
"""
import time

import cv2
import numpy as np
import onnx
import vision.utils.box_utils_numpy as box_utils
from caffe2.python.onnx import backend
from onnx_tf.backend import prepare

# onnx runtime
import onnxruntime as ort


def predict(width, height, confidences, boxes, prob_threshold, iou_threshold=0.3, top_k=-1):
    boxes = boxes[0]
    confidences = confidences[0]
    picked_box_probs = []
    picked_labels = []
    for class_index in range(1, confidences.shape[1]):
        probs = confidences[:, class_index]
        mask = probs > prob_threshold
        probs = probs[mask]
        if probs.shape[0] == 0:
            continue
        subset_boxes = boxes[mask, :]
        box_probs = np.concatenate([subset_boxes, probs.reshape(-1, 1)], axis=1)
        box_probs = box_utils.hard_nms(box_probs,
                                       iou_threshold=iou_threshold,
                                       top_k=top_k,
                                       )
        picked_box_probs.append(box_probs)
        picked_labels.extend([class_index] * box_probs.shape[0])
    if not picked_box_probs:
        return np.array([]), np.array([]), np.array([])
    picked_box_probs = np.concatenate(picked_box_probs)
    picked_box_probs[:, 0] *= width
    picked_box_probs[:, 1] *= height
    picked_box_probs[:, 2] *= width
    picked_box_probs[:, 3] *= height
    return picked_box_probs[:, :4].astype(np.int32), np.array(picked_labels), picked_box_probs[:, 4]


label_path = "models/voc-model-labels2.txt"

onnx_path = "models/onnx/MASK-face-v2-640-RFB-Loss-3.onnx"
class_names = [name.strip() for name in open(label_path).readlines()]

predictor = onnx.load(onnx_path)
onnx.checker.check_model(predictor)
onnx.helper.printable_graph(predictor.graph)
#predictor = backend.prepare(predictor, device="CPU")  # default CPU
predictor = prepare(predictor, device="CPU")

ort_session = ort.InferenceSession(onnx_path)
input_name = ort_session.get_inputs()[0].name

#some paths 
label_path = "./models/voc-model-labels.txt"
result_path = "./detect_imgs_results_video_onnx"

cap = cv2.VideoCapture("./videos/video_test2.mkv")  # capture from camera

threshold = 0.9

if not os.path.exists(result_path):
    os.makedirs(result_path)

#create an output text file to record the detections 
filename ="./output_detection_video_onnx.txt"
if os.path.exists(filename):
      append_write = 'a' # append if already exists
else:
      append_write = 'w' # make a new file if not
text_file = open(filename, append_write)

#classes to be detected in total
timer = Timer()
sum = 0
face_sum = 0
mask_sum = 0
frame_count = 0

while True:
    ret, orig_image = cap.read()
    if orig_image is None:
        print("no img")
        break
    image = cv2.cvtColor(orig_image, cv2.COLOR_BGR2RGB)
    image = cv2.resize(image, (320, 240))
    # image = cv2.resize(image, (640, 480))
    image_mean = np.array([127, 127, 127])
    image = (image - image_mean) / 128
    image = np.transpose(image, [2, 0, 1])
    image = np.expand_dims(image, axis=0)
    image = image.astype(np.float32)
    # confidences, boxes = predictor.run(image)
    time_time = time.time()
    confidences, boxes = ort_session.run(None, {input_name: image})
    print("cost time:{}".format(time.time() - time_time))
    boxes, labels, probs = predict(orig_image.shape[1], orig_image.shape[0], confidences, boxes, threshold)
    for i in range(boxes.shape[0]):
        box = boxes[i, :]
        label = f"""{class_names[labels[i]]}: {probs[i]:.2f}"""
        text_file.write("%s,%f,%f,%f,%f,%s\n" % ("video_"+str(frame_count), box[0], box[1], box[2], box[3], label[0:4]))

        if label.find("face") == 0 or label.find("sans_masque") == 0 or label.find("SANS_MASQUE") == 0:
             label = "face"
             cv2.rectangle(orig_image, (box[0], box[1]), (box[2], box[3]), (0, 0, 255), 2)
             print('\a')
             face_sum = face_sum + 1
             print('\a')
             cv2.imwrite(os.path.join(result_path,'video_'+str(frame_count)+'.jpg'), orig_image)
        else:
             label = "mask"
             cv2.rectangle(orig_image, (box[0], box[1]), (box[2], box[3]), (0, 255, 255), 2)
             mask_sum = mask_sum + 1
        cv2.putText(orig_image, label,
                     (box[0] + 15, box[1] + 15),
                     cv2.FONT_HERSHEY_SIMPLEX,
                     0.7,  # font scale
                     (255, 0, 255),
                     2)  # line type
        cv2.putText(orig_image, str(boxes.size(0)), (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 255), 2)
    orig_image = cv2.resize(orig_image, None, None, fx=0.8, fy=0.8)
    sum += boxes.shape[0]
    #orig_image = cv2.resize(orig_image, (0, 0), fx=0.7, fy=0.7)
    cv2.imshow('Detected MASK-face', orig_image)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()

text_file.close()

print("Total faces: {} where faces without mask: {} and with mask: {}".format(sum, face_sum, mask_sum))